#ifndef DISTANCESENSOR_H
#define DISTANCESENSOR_H

#include <Arduino.h>

void measureDistance(int trigPin1, int echoPin1, int trigPin2, int echoPin2, int trigPin3, int echoPin3, int& distance1, int& distance2, int& distance3);

#endif