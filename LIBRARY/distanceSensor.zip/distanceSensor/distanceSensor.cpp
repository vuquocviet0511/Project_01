#include "distanceSensor.h"

void measureDistance(int trigPin1, int echoPin1, int trigPin2, int echoPin2, int trigPin3, int echoPin3, int& distance1, int& distance2, int& distance3) {
  // Đo khoảng cách từ cảm biến 1
  digitalWrite(trigPin1, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin1, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin1, LOW);
  int duration1 = pulseIn(echoPin1, HIGH);
  distance1 = duration1 * 0.034 / 2;

  // Đo khoảng cách từ cảm biến 2
  digitalWrite(trigPin2, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin2, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin2, LOW);
  int duration2 = pulseIn(echoPin2, HIGH);
  distance2 = duration2 * 0.034 / 2;

  // Đo khoảng cách từ cảm biến 3
  digitalWrite(trigPin3, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin3, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin3, LOW);
  int duration3 = pulseIn(echoPin3, HIGH);
  distance3 = duration3 * 0.034 / 2;
}
