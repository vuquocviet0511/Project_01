#include "Arduino.h"
#include "battery.h"

float calculateBatteryPercentage(int voltPin) {
    float R1=33000.0;
    float R2=7500.0;
    float correctionfactor = .3;
    int volt = analogRead(voltPin);
    float vout = (volt * 5.0 ) / 1024.0 ;
    float voltage = vout / ( R2/(R1 + R2)) ;
    voltage = voltage + correctionfactor;
    int percentage;
    if (voltage > 0 && voltage < 6) {
        percentage = 0;
    } else {
        percentage = ((voltage - 6) / (8.4 - 6)) * 100;
    }
    return percentage;
}
