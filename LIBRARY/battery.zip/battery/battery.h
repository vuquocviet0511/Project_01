#ifndef BATTERY_H
#define BATTERY_H

float calculateBatteryPercentage(int voltPin);

#endif
